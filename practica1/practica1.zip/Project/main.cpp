#include <iostream>
#include "unizar.h"

using namespace std;
/*
cosas que revisar:
    calificaci�n
    como borrar el vector entreo en eliminarexpediente


*/
int main()
{

    unizar expediente;
    crearExp("Rebeca Vegas","Administracion y direccion de empresas",expediente);

    for(int i=0; i<40;i++){
        ayadirSignature(expediente,4400+i);
        ayadirCali(expediente,4400+i,i);
    }
    cout<<generaCadena(expediente);
    cout<<"fin";



}

